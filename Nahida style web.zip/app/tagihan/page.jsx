'use client';

import { useState } from 'react';

export default function TagihanPage() {
  const [code, setCode] = useState('HP3');
  const [customerNo, setCustomerNo] = useState('');
  const [reffId, setReffId] = useState('');
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [cekRes, setCekRes] = useState(null);
  const [bayarRes, setBayarRes] = useState(null);

  async function handleCek(e) {
    e.preventDefault();
    setBayarRes(null);
    const r = await fetch('/api/transaksi/cek-tagihan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code,
        customer_no: customerNo,
        reff_id: reffId || `TAGIHAN-${Date.now()}`,
        phone,
        name,
      }),
    });
    const json = await r.json();
    setCekRes(json);
  }

  async function handleBayar() {
    if (!cekRes) return;
    const data = cekRes.data?.data || cekRes.data;
    const realReff =
      cekRes.reff_id ||
      cekRes.data?.reff_id ||
      data?.reff_id ||
      reffId ||
      `TAGIHAN-${Date.now()}`;

    const r = await fetch('/api/transaksi/bayar-tagihan', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        code,
        customer_no: customerNo,
        reff_id: realReff,
        customerId: cekRes.customerId || null,
      }),
    });
    const json = await r.json();
    setBayarRes(json);
  }

  return (
    <div className="caeup-grid">
      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Cek Tagihan Pascabayar</div>
            <div className="caeup-card-sub">PLN, PDAM, HP Pascabayar – via Atlantic H2H.</div>
          </div>
          <span className="caeup-badge">2 Langkah</span>
        </div>
        <div className="caeup-card-body">
          <form className="caeup-form" onSubmit={handleCek}>
            <div className="caeup-field">
              <label className="caeup-label">No HP Customer (opsional, untuk menyimpan ke DB)</label>
              <input
                className="caeup-input"
                placeholder="62xxxxxxxxxx"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Nama Customer (opsional)</label>
              <input
                className="caeup-input"
                placeholder="Nama pelanggan"
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Kode Layanan</label>
              <input
                className="caeup-input"
                placeholder="HP3, PLNPOST, PDAM01, ..."
                value={code}
                onChange={e => setCode(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">ID Pelanggan</label>
              <input
                className="caeup-input"
                placeholder="No pelanggan / kontrak"
                value={customerNo}
                onChange={e => setCustomerNo(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Reff ID (opsional)</label>
              <input
                className="caeup-input"
                placeholder="Jika kosong akan dibuat otomatis"
                value={reffId}
                onChange={e => setReffId(e.target.value)}
              />
            </div>
            <button className="caeup-btn" type="submit">
              Cek Tagihan
            </button>
            <p className="caeup-muted">
              Step 1: cek tagihan, Step 2: bayar tagihan setelah nominal keluar.
            </p>
          </form>
        </div>
      </section>

      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Hasil Cek & Pembayaran</div>
            <div className="caeup-card-sub">Total tagihan, status, dan detail lainnya.</div>
          </div>
        </div>
        <div className="caeup-card-body">
          {cekRes ? (
            <>
              <h4 className="caeup-label">Hasil Cek</h4>
              <pre className="caeup-json">
                {JSON.stringify(cekRes, null, 2)}
              </pre>
              <button className="caeup-btn" style={{ marginTop: 10 }} onClick={handleBayar}>
                Bayar Tagihan
              </button>
            </>
          ) : (
            <p className="caeup-muted">Belum ada cek tagihan. Isi form di kiri terlebih dahulu.</p>
          )}

          {bayarRes && (
            <>
              <h4 className="caeup-label" style={{ marginTop: 12 }}>Hasil Pembayaran</h4>
              <pre className="caeup-json">
                {JSON.stringify(bayarRes, null, 2)}
              </pre>
            </>
          )}
        </div>
      </section>
    </div>
  );
}
