import './globals.css';
import Link from 'next/link';

export const metadata = {
  title: 'CaeUP Panel',
  description: 'CaeUP Atlantic H2H Integration',
};

export default function RootLayout({ children }) {
  return (
    <html lang="id">
      <body className="caeup-shell">
        <header className="caeup-header">
          <div className="caeup-header-inner">
            <div className="caeup-logo">
              <div className="caeup-logo-icon" />
              <div>
                <div className="caeup-logo-text-main">CaeUP</div>
                <div className="caeup-logo-text-sub">Atlantic H2H · Nahida Green</div>
              </div>
            </div>
            <nav className="caeup-nav">
              <Link href="/">Dashboard</Link>
              <Link href="/topup">Topup</Link>
              <Link href="/tagihan">Tagihan</Link>
              <Link href="/deposit">Deposit</Link>
              <Link href="/customers">Customer</Link>
            </nav>
          </div>
        </header>
        <main className="caeup-main">
          <div className="caeup-main-inner">{children}</div>
        </main>
      </body>
    </html>
  );
}
