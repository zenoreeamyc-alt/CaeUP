import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';

export async function POST(req) {
  try {
    const body = await req.json();
    const { event, status, data } = body || {};

    if (!event || !data) {
      return NextResponse.json({ ok: false }, { status: 400 });
    }

    if (event === 'transaksi' || event === 'transaksi.pascabayar') {
      const reffId = data.reff_id;
      if (reffId) {
        await prisma.order.updateMany({
          where: { reffId },
          data: {
            status: data.status || status,
            providerId: data.id || undefined,
            amount: data.price ? parseInt(data.price, 10) : undefined,
            raw: body,
          },
        });
      }
    } else if (event === 'transfer') {
      // bisa disimpan ke tabel lain jika ingin, sementara hanya log ke order
      const reffId = data.reff_id;
      if (reffId) {
        await prisma.order.updateMany({
          where: { reffId },
          data: {
            status: data.status || status,
            providerId: data.id || undefined,
            amount: data.nominal ? parseInt(data.nominal, 10) : undefined,
            raw: body,
          },
        });
      }
    }

    return NextResponse.json({ ok: true });
  } catch (err) {
    console.error(err);
    return NextResponse.json({ ok: false }, { status: 500 });
  }
}

export const dynamic = 'force-dynamic';
