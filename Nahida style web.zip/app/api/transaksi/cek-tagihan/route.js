import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { cekTagihan } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { code, reff_id, customer_no, phone, name } = body;

    if (!code || !customer_no) {
      return NextResponse.json(
        { success: false, message: 'code & customer_no wajib diisi' },
        { status: 400 },
      );
    }

    let customer = null;
    if (phone) {
      customer = await prisma.customer.upsert({
        where: { phone },
        update: { name: name || undefined },
        create: { phone, name: name || null },
      });
    }

    const finalReff = reff_id || `TAGIHAN-${Date.now()}`;

    const atl = await cekTagihan({
      code,
      reff_id: finalReff,
      customer_no,
    });

    return NextResponse.json({
      success: true,
      reff_id: finalReff,
      customerId: customer?.id || null,
      data: atl,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
