import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { bayarTagihan } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { code, reff_id, customer_no, customerId } = body;

    if (!code || !reff_id || !customer_no) {
      return NextResponse.json(
        { success: false, message: 'code, reff_id, customer_no wajib diisi' },
        { status: 400 },
      );
    }

    const atl = await bayarTagihan({ code, reff_id, customer_no });
    const data = atl.data || {};

    let customer = null;
    if (customerId) {
      customer = await prisma.customer.findUnique({ where: { id: customerId } });
    }

    const order = await prisma.order.create({
      data: {
        reffId: reff_id,
        type: 'pascabayar',
        code,
        target: customer_no,
        amount: data.price ? parseInt(data.price, 10) : null,
        status: data.status || 'processing',
        providerId: data.id || null,
        raw: atl,
        customerId: customer?.id,
      },
    });

    return NextResponse.json({ success: true, order, atlantic: atl });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
