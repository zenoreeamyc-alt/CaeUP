import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { transaksiStatus } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { reff_id, type = 'prabayar' } = body;

    if (!reff_id) {
      return NextResponse.json(
        { success: false, message: 'reff_id wajib diisi' },
        { status: 400 },
      );
    }

    const order = await prisma.order.findUnique({
      where: { reffId: reff_id },
    });

    if (!order || !order.providerId) {
      return NextResponse.json(
        { success: false, message: 'Order tidak ditemukan / belum punya providerId' },
        { status: 404 },
      );
    }

    const atl = await transaksiStatus({ id: order.providerId, type });

    const data = atl.data || {};
    const updated = await prisma.order.update({
      where: { id: order.id },
      data: {
        status: data.status || order.status,
        raw: atl,
      },
    });

    return NextResponse.json({ success: true, order: updated, atlantic: atl });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
