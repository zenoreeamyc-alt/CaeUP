import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { transaksiCreate } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { phone, name, code, target } = body;

    if (!phone || !code || !target) {
      return NextResponse.json(
        { success: false, message: 'phone, code, target wajib diisi' },
        { status: 400 },
      );
    }

    const customer = await prisma.customer.upsert({
      where: { phone },
      update: { name: name || undefined },
      create: { phone, name: name || null },
    });

    const reff_id =
      body.reff_id ||
      `TRX-${Date.now()}-${Math.floor(Math.random() * 9999)}`;

    const pendingOrder = await prisma.order.create({
      data: {
        reffId: reff_id,
        type: 'prabayar',
        code,
        target,
        status: 'pending',
        customerId: customer.id,
      },
    });

    const atlRes = await transaksiCreate({ code, reff_id, target });
    const data = atlRes.data || {};

    const updatedOrder = await prisma.order.update({
      where: { id: pendingOrder.id },
      data: {
        providerId: data.id || null,
        amount: data.price ? parseInt(data.price, 10) : null,
        status: data.status || 'processing',
        raw: atlRes,
      },
    });

    return NextResponse.json({
      success: true,
      order: updatedOrder,
      atlantic: atlRes,
    });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
