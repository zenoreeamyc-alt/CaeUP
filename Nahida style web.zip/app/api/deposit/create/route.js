import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { depositCreate } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { amount, type, metode, phone } = body;

    if (!amount || !type || !metode) {
      return NextResponse.json(
        { success: false, message: 'amount, type, metode wajib diisi' },
        { status: 400 },
      );
    }

    let customer = null;
    if (phone) {
      customer = await prisma.customer.upsert({
        where: { phone },
        update: {},
        create: { phone },
      });
    }

    const reff_id = `DEP-${Date.now()}-${Math.floor(Math.random() * 9999)}`;

    const atl = await depositCreate({
      nominal: amount,
      type,
      metode,
      reff_id,
    });

    const data = atl.data || {};

    const deposit = await prisma.deposit.create({
      data: {
        reffId: reff_id,
        method: metode,
        amount: amount,
        status: data.status || 'pending',
        providerId: data.id || null,
        raw: atl,
        customerId: customer?.id,
      },
    });

    return NextResponse.json({ success: true, deposit, atlantic: atl });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
