import { NextResponse } from 'next/server';
import { prisma } from '@/lib/db';
import { depositInstant } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const { reff_id, action = true } = body;

    if (!reff_id) {
      return NextResponse.json(
        { success: false, message: 'reff_id wajib diisi' },
        { status: 400 },
      );
    }

    const dep = await prisma.deposit.findUnique({ where: { reffId: reff_id } });
    if (!dep || !dep.providerId) {
      return NextResponse.json(
        { success: false, message: 'Deposit tidak ditemukan / belum punya providerId' },
        { status: 404 },
      );
    }

    const atl = await depositInstant({ id: dep.providerId, action });
    const data = atl.data || {};

    const updated = await prisma.deposit.update({
      where: { id: dep.id },
      data: {
        status: data.status || dep.status,
        raw: atl,
      },
    });

    return NextResponse.json({ success: true, deposit: updated, atlantic: atl });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
