import { NextResponse } from 'next/server';
import { depositMetode } from '@/lib/atlantic/api';

export async function POST(req) {
  try {
    const body = await req.json();
    const data = await depositMetode(body);
    return NextResponse.json({ success: true, data });
  } catch (err) {
    console.error(err);
    return NextResponse.json(
      { success: false, message: err.message },
      { status: 500 },
    );
  }
}
