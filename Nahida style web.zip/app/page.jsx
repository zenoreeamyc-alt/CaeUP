'use client';

import Link from 'next/link';

export default function Home() {
  return (
    <>
      <div className="caeup-grid">
        <section className="caeup-card">
          <div className="caeup-card-header">
            <div>
              <div className="caeup-card-title">Panel CaeUP</div>
              <div className="caeup-card-sub">
                Kelola topup prabayar, tagihan, deposit – terhubung langsung Atlantic H2H.
              </div>
            </div>
            <span className="caeup-badge">Realtime API</span>
          </div>
          <div className="caeup-card-body">
            <p className="caeup-muted">
              Mulai dari topup cepat, cek tagihan pascabayar, sampai pengisian saldo otomatis.
            </p>
            <div className="caeup-chip-row">
              <span className="caeup-chip">Pulsa &amp; Data</span>
              <span className="caeup-chip">Game</span>
              <span className="caeup-chip">E-Wallet</span>
              <span className="caeup-chip">PLN / PDAM</span>
              <span className="caeup-chip">Deposit QRIS</span>
            </div>
          </div>
        </section>

        <aside className="caeup-card">
          <div className="caeup-card-header">
            <div>
              <div className="caeup-card-title">Navigasi Cepat</div>
              <div className="caeup-card-sub">Pilih modul yang ingin kamu gunakan.</div>
            </div>
          </div>
          <div className="caeup-card-body">
            <div className="caeup-form">
              <Link href="/topup" className="caeup-btn" style={{ textAlign: 'center' }}>
                • Topup Prabayar
              </Link>
              <Link href="/tagihan" className="caeup-btn" style={{ textAlign: 'center', background: 'linear-gradient(135deg,#a6ffe0,#55ffb0)' }}>
                • Tagihan Pascabayar
              </Link>
              <Link href="/deposit" className="caeup-btn" style={{ textAlign: 'center', background: 'linear-gradient(135deg,#d2ffe9,#7cffc4)', color: '#01311c' }}>
                • Deposit / Topup Saldo
              </Link>
              <Link href="/customers" className="caeup-btn" style={{ textAlign: 'center', background: 'linear-gradient(135deg,#093820,#15d16e)', color: '#eafff9' }}>
                • Customer & Riwayat
              </Link>
            </div>
          </div>
        </aside>
      </div>
    </>
  );
}
