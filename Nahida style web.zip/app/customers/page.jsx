'use client';

import { useEffect, useState } from 'react';

export default function CustomersPage() {
  const [data, setData] = useState(null);

  useEffect(() => {
    fetch('/api/customers/list')
      .then(r => r.json())
      .then(setData)
      .catch(console.error);
  }, []);

  return (
    <div className="caeup-card">
      <div className="caeup-card-header">
        <div>
          <div className="caeup-card-title">Customer & Riwayat</div>
          <div className="caeup-card-sub">Daftar customer, order, dan deposit dari CaeUP.</div>
        </div>
        <span className="caeup-badge">Read-only</span>
      </div>
      <div className="caeup-card-body">
        {data ? (
          <pre className="caeup-json">
            {JSON.stringify(data, null, 2)}
          </pre>
        ) : (
          <p className="caeup-muted">Memuat data customer...</p>
        )}
      </div>
    </div>
  );
}
