'use client';

import { useState } from 'react';

export default function TopupPage() {
  const [phone, setPhone] = useState('');
  const [name, setName] = useState('');
  const [code, setCode] = useState('ML10');
  const [target, setTarget] = useState('');
  const [res, setRes] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setRes(null);

    const r = await fetch('/api/topup/prabayar', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ phone, name, code, target }),
    });

    const json = await r.json();
    setLoading(false);
    setRes(json);
  }

  return (
    <div className="caeup-grid">
      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Topup Prabayar</div>
            <div className="caeup-card-sub">Pulsa, data, game, e-wallet – via Atlantic H2H.</div>
          </div>
          <span className="caeup-badge">Manual + Auto</span>
        </div>
        <div className="caeup-card-body">
          <form className="caeup-form" onSubmit={handleSubmit}>
            <div className="caeup-field">
              <label className="caeup-label">No WhatsApp / HP Customer</label>
              <input
                className="caeup-input"
                placeholder="62xxxxxxxxxx"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Nama Customer (opsional)</label>
              <input
                className="caeup-input"
                placeholder="Nama panggilan"
                value={name}
                onChange={e => setName(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Kode Produk (dari price_list)</label>
              <input
                className="caeup-input"
                placeholder="ML10, PULSA10, DANA20, ..."
                value={code}
                onChange={e => setCode(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Target Tujuan</label>
              <input
                className="caeup-input"
                placeholder="No HP / ID Game / No Pelanggan"
                value={target}
                onChange={e => setTarget(e.target.value)}
              />
            </div>
            <button className="caeup-btn" type="submit" disabled={loading}>
              {loading ? 'Memproses...' : 'Buat Transaksi'}
            </button>
            <p className="caeup-muted">
              Reff ID akan dibuat otomatis per transaksi dan disimpan di database order.
            </p>
          </form>
        </div>
      </section>

      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Hasil & Respon API</div>
            <div className="caeup-card-sub">Debug langsung dari Atlantic H2H.</div>
          </div>
        </div>
        <div className="caeup-card-body">
          {res ? (
            <pre className="caeup-json">
              {JSON.stringify(res, null, 2)}
            </pre>
          ) : (
            <p className="caeup-muted">Belum ada transaksi. Kirim satu transaksi untuk melihat respon.</p>
          )}
        </div>
      </section>
    </div>
  );
}
