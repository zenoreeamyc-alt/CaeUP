'use client';

import { useState } from 'react';

export default function DepositPage() {
  const [amount, setAmount] = useState('');
  const [type, setType] = useState('ewallet');
  const [metode, setMetode] = useState('qris');
  const [phone, setPhone] = useState('');
  const [result, setResult] = useState(null);
  const [loading, setLoading] = useState(false);

  async function handleCreate(e) {
    e.preventDefault();
    setLoading(true);
    setResult(null);
    const r = await fetch('/api/deposit/create', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ amount: Number(amount), type, metode, phone }),
    });
    const json = await r.json();
    setLoading(false);
    setResult(json);
  }

  return (
    <div className="caeup-grid">
      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Deposit Saldo</div>
            <div className="caeup-card-sub">Buat deposit via bank / e-wallet / VA.</div>
          </div>
          <span className="caeup-badge">QRIS Ready</span>
        </div>
        <div className="caeup-card-body">
          <form className="caeup-form" onSubmit={handleCreate}>
            <div className="caeup-field">
              <label className="caeup-label">No HP Customer (opsional)</label>
              <input
                className="caeup-input"
                placeholder="62xxxxxxxxxx"
                value={phone}
                onChange={e => setPhone(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Nominal</label>
              <input
                className="caeup-input"
                placeholder="Contoh: 50000"
                value={amount}
                onChange={e => setAmount(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Type</label>
              <input
                className="caeup-input"
                placeholder="bank / ewallet / va"
                value={type}
                onChange={e => setType(e.target.value)}
              />
            </div>
            <div className="caeup-field">
              <label className="caeup-label">Metode</label>
              <input
                className="caeup-input"
                placeholder="qris / dana / dll"
                value={metode}
                onChange={e => setMetode(e.target.value)}
              />
            </div>
            <button className="caeup-btn" type="submit" disabled={loading}>
              {loading ? 'Memproses...' : 'Buat Deposit'}
            </button>
            <p className="caeup-muted">
              Detail QR atau instruksi pembayaran tergantung respon dari Atlantic H2H.
            </p>
          </form>
        </div>
      </section>

      <section className="caeup-card">
        <div className="caeup-card-header">
          <div>
            <div className="caeup-card-title">Respon Deposit</div>
            <div className="caeup-card-sub">Termasuk ID deposit & status awal.</div>
          </div>
        </div>
        <div className="caeup-card-body">
          {result ? (
            <pre className="caeup-json">
              {JSON.stringify(result, null, 2)}
            </pre>
          ) : (
            <p className="caeup-muted">Belum ada deposit. Isi form di kiri untuk mulai.</p>
          )}
        </div>
      </section>
    </div>
  );
}
